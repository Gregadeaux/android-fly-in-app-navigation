package com.deaux.fansample;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.deaux.fan.FanView;

/**
 * A sample activity that demonstrates the {@link FanView} in both horizontal
 * and vertical modes. If this activity is started with intExtra of either {@link #VERTICAL_FAN}
 * and {@link #HORIZONTAL_FAN}. Activity defaults to {@link #HORIZONTAL_FAN} if no extra provided
 */
public class SampleActivity extends Activity {
	/**
	 * Logging
	 */
	private static final String TAG = "SampleActivity";
    
	/**
	 * The {@link FanView} that we will place the child views in
	 */
	private FanView mFan;
	
	/**
	 * Final tag to control the orientation of the {@link #mFan} view
	 */
	public static final String ORIENTATION_TAG = "fan_orientation";
	/**
	 * Final variable to control the orientation of the {@link #mFan} view
	 */
	public static final int VERTICAL_FAN = 0;
	/**
	 * Final variable to control the orientation of the {@link #mFan} view
	 */
	public static final int HORIZONTAL_FAN = 1;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        if(getIntent() != null){
        	switch(getIntent().getIntExtra(ORIENTATION_TAG, VERTICAL_FAN)){
        	case HORIZONTAL_FAN:
        		Log.d(TAG,"orientation : " + HORIZONTAL_FAN);
        		setContentView(R.layout.test_horizontal);
        		mFan = (FanView) findViewById(R.id.fan_view);
        		mFan.setViews(R.layout.main, R.layout.fan_horizontal);
        		break;
        	case VERTICAL_FAN:
        		default:
        			Log.d(TAG,"orientation : " + VERTICAL_FAN);
        			setContentView(R.layout.test_vertical);
        			mFan = (FanView) findViewById(R.id.fan_view);
        			mFan.setViews(R.layout.main, R.layout.fan_vertical);
        			break;
        	}
        }
        
        /*
         * fan.setFadeOnMenuToggle(true);
         * fan.setAnimationDuration(500);
         * fan.setIncludeDropshadow(false);
         */
    }
    
    
    public void unclick(View v) {
    	Log.d(TAG,"CLOSE");
    	mFan.showMenu();
    }
    
    public void click(View v) {
    	Log.d(TAG,"OPEN");
    	mFan.showMenu();
    }
    
}