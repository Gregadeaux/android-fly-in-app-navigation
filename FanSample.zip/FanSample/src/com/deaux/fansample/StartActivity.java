package com.deaux.fansample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * Activity starts the {@link SampleActivity} with the user's choice of a 
 * horizontal or vertical fan. Activity provides an intExtra to the {@link SampleActivity}
 * start intent that is either {@link #SampleActivity.VERTICAL_FAN} of {@link SampleActivity.HORIZONTAL_FAN}
 */
public class StartActivity extends Activity {
	 	@Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.start_main);
	        
	        //Get references to the buttons
	        Button vButton = (Button) findViewById(R.id.vertical_button);
	        Button hButton = (Button) findViewById(R.id.horizontal_button);
	        
	        //Set click listener to start fan activity in vertical mode
	        vButton.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					Intent fanIntent = new Intent(getApplicationContext(), SampleActivity.class);
					fanIntent.putExtra(SampleActivity.ORIENTATION_TAG, SampleActivity.VERTICAL_FAN);
	                startActivity(fanIntent);
				}
	        	
	        });
	        //Set click listener to start fan activity in horizontal mode
	        hButton.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					Intent fanIntent = new Intent(getApplicationContext(), SampleActivity.class);
					fanIntent.putExtra(SampleActivity.ORIENTATION_TAG, SampleActivity.HORIZONTAL_FAN);
	                startActivity(fanIntent);
				}
	        	
	        });
	    }
}
